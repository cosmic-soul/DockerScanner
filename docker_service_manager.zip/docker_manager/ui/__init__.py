"""
User interface components for Docker service management.
"""
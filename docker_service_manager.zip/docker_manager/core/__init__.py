"""
Core functionality for Docker service management.
"""
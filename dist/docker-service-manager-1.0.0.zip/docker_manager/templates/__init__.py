"""
Template package for extending Docker Service Manager.

This package contains templates and examples for extending
the Docker Service Manager with new functionality.
"""
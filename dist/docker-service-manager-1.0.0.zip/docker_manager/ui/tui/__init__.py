"""
Terminal User Interface (TUI) components for Docker service management.

This package contains classes and functions for creating an
interactive terminal user interface using py-cui.
"""
"""
Utility functions for Docker service management.
"""